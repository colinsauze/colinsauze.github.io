void parport_init();
void move(uint8_t direction);
void stop();
