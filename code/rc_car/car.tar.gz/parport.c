/*
parallel port routines for accessing the remote control car
(C) Copyright Colin Sauze 2007
http://users.aber.ac.uk/cjs06/rc_car

I think this is the only linux/unix specific part of the code, 
if you rewrite this file you should be able to make this code 
work in windows (should you really want to!).

This program is released under the GPL, here's the legal bit:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/io.h>

#define base 0x378

void parport_init()
{
    if(ioperm(base,1,1))
    {
        fprintf(stderr,"Access denied, are you root?\n");
        exit(1);
    }
}

void move(uint8_t direction)
{
    outb(direction,base);
}

void stop()
{
    outb(0,base);
}
