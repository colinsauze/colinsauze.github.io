/*
Remote control car SDL interface
(C) Copyright Colin Sauze 2007
http://users.aber.ac.uk/cjs06/rc_car

This program allows you to control a remote control car connected via the parallel port using the intstructions
from http://users.aber.ac.uk/cjs06/rc_car.

This code was written for the 2007 National Science and Engineering Week and intended to teach 11-14 year olds
about radio delays, binary code and transistors.

The program allows the user a 2 minute turn before kicking them off. During these 2 minutes the delay
between pressing a key and the command being sent to the car increases from 10 milliseconds to 2 seconds.

There's a "easy" mode which can be specified with the -e option on the command line to disable the increasing delay.

Another command line parameter allows the selection of the colour of the car. For Science week we used three cars
one coloured red, one green and one blue. These were tracked with a webcam, unfortunately there wasn't time to 
integrate that information into this code (maybe next year). 

This program is released under the GPL, here's the legal bit:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <cstdlib> // For some useful functions such as atexit :)
#include <stdint.h>
#include <unistd.h>
#include "SDL.h" // main SDL header
#include "SDL_image.h" // image library, if your only using BMP's, get ride of this.
#include "SFont.h"
#include "get_image.h"
#include "parport.h"
#include "queue.h"
 
#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define true 1
#define false 0 //You might have to declaire True and False.
#define COLORKEY 255, 0, 255 //Your Transparent colour

#define FORWARD 1
#define BACK 2
#define LEFT 4
#define RIGHT 8


#define RED 1
#define GREEN 2
#define BLUE 3

SDL_Surface *screen; //This pointer will reference the backbuffer
SDL_Surface *logo;
SFont_Font* Font;
uint8_t easy_mode=0;
uint8_t colour=RED;

//I have set the flag SDL_SWSURFACE for a window :)
int InitVideo(Uint32 flags = SDL_DOUBLEBUF | SDL_SWSURFACE) {
    // Load SDL
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
    fprintf(stderr, "Unable to initialize SDL: %s\n", SDL_GetError());
    return false;
    }
    atexit(SDL_Quit); // Clean it up nicely :)

    // fullscreen can be toggled at run time :) any you might want to change the flags with params?
    //set the main screen to SCREEN_WIDTHxSCREEN_HEIGHT with a colour depth of 16:
    screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 16, flags);
    if (screen == NULL) {
    fprintf(stderr, "Unable to set video mode: %s\n", SDL_GetError());
    return false;
    }
    //full screen mode
    SDL_WM_ToggleFullScreen(screen);
    return true;
}

//--------------------------- Drawing Stuff -------------------------
SDL_Surface* LoadImage(char *file, int &exitstate) {
    SDL_Surface *tmp;
    tmp = IMG_Load(file);
    exitstate = false;

    if (tmp == NULL) 
    {
        fprintf(stderr, "Error: '%s' could not be opened: %s\n", file, IMG_GetError());
    }
    else
    {
        if(SDL_SetColorKey(tmp, SDL_SRCCOLORKEY | SDL_RLEACCEL, SDL_MapRGB(tmp->format, COLORKEY)) == -1)
        fprintf(stderr, "Warning: colorkey will not be used, reason: %s\n", SDL_GetError());
        exitstate = true;
    }
    return tmp;
}

void DrawImage(SDL_Surface *srcimg, int sx, int sy, int sw, int sh, SDL_Surface *dstimg, int dx, int dy ) 
{
    if (srcimg == NULL) return; //If theres no image, or its 100% transparent.
    SDL_Rect src, dst;

    src.x = sx;  src.y = sy;  src.w = sw;  src.h = sh;
    dst.x = dx;  dst.y = dy;  dst.w = src.w;  dst.h = src.h;

    SDL_BlitSurface(srcimg, &src, dstimg, &dst);
}

void clear_screen()
{
    SDL_Rect clear;
    //clear the screen
    clear.x=0;
    clear.y=0;
    clear.w=SCREEN_WIDTH;
    clear.h=SCREEN_HEIGHT;
    SDL_FillRect(screen,&clear,0);
    SDL_Flip(screen); //Refresh the screen
}

/*
The main loop of the program

this does the following:

displays some introduction text, waits 5 seconds and then waits for the user to press a key

enters main loop

calculates the delay time which increases by 1 second every minute,
this is the amount of time an event spends in the queue. 
It is intended to simulate the effects of radio latency.

displays the current delay time on the screen

display the time left in this turn (turns last 2 minutes)

tests if any keyboard events occured (key up and key down events)
we add these events to our event queue, calculating what values this key would send to the parallel port
keydown events turn on a certain bit, key off values turn it off

display the current value which we are outputting to the parallel port in both base 10 and binary

test if we've got an event in memory and if its time to execute that event, if so set the parallel port to the value of the event

get a new event from the queue if there is one and store it as our current event in memory

*/
void mainloop()
{
    uint8_t direction=0,dir2=0; //the current command to send to the parallel port
    uint8_t proceed=0,event_occured=0;
    uint8_t q_pressed=0,shift_pressed=0;
    int delay=100;
    char done=0;
    char delay_string[20];
    char time_left[40];
    char direction_string[30];
    char direction_binary[5];
    uint32_t turn_start_time;
    uint32_t turn_end_time;
    SDL_Event keyevent;    //The SDL event that we will poll to get events.
    SDL_Rect blank;
    event_item latest_event,current_event;
    event_item new_event;
    SFont_Font *ColourFont;

    //setup the event queue
    init_queue();

    while(done!=1)
    {
        stop();
        clear_screen();
        SFont_Write(screen,Font,5,10,"Can you get the car through the maze?");

        SFont_Write(screen,Font,20,50,"You are the ");

        switch(colour)
        {
            case RED:
                ColourFont = SFont_InitFont(IMG_Load("red_font.png"));
                if(!ColourFont) {
                    fprintf(stderr, "An error occured while loading the font.");
                    exit(1);
                }
                SFont_Write(screen,ColourFont,200,50,"red car");
                break;
            case BLUE:
                ColourFont = SFont_InitFont(IMG_Load("blue_font.png"));
                if(!ColourFont) {
                    fprintf(stderr, "An error occured while loading the font.");
                    exit(1);
                }
                SFont_Write(screen,ColourFont,200,50,"blue car");
                break;
            case GREEN:
                ColourFont = SFont_InitFont(IMG_Load("green_font.png"));
                if(!ColourFont) {
                    fprintf(stderr, "An error occured while loading the font.");
                    exit(1);
                }
                SFont_Write(screen,ColourFont,200,50,"green car");
                break;
        }

        SFont_Write(screen,Font,20,100,"You have 2 minutes to get the car to the other end");
        SFont_Write(screen,Font,20,130,"of the maze.");

        SFont_Write(screen,Font,20,180,"Control the car with the arrow keys on the keyboard.");
        SFont_Write(screen,Font,20,230,"The longer you play the more delay there will be ");
        SFont_Write(screen,Font,20,260,"from you pressing a key to the car moving.");
        SFont_Write(screen,Font,20,310,"This is to give you some idea what its like to");
        SFont_Write(screen,Font,20,340,"control a robot which is a long way away.");
        SFont_Write(screen,Font,20,390,"If you had a robot on the moon it would take 2 seconds");
        SFont_Write(screen,Font,20,420,"between you sending it a command and it moving.");

        SDL_Flip(screen); //Refresh the screen
        SDL_Delay(5000); //Wait 5 seconds

        SFont_Write(screen,Font,100,550,"Press any key to start....");
        SDL_Flip(screen);
        proceed=0;

        while(!proceed)
        {
            while (SDL_PollEvent(&keyevent))   //Poll our SDL key event for any keystrokes.
            {
                switch(keyevent.type)
                {
                    case SDL_KEYDOWN:
                        proceed=1;
                        break;
                    case SDL_QUIT:
                        done = 1;
                        break;
                }

            }
            SDL_Delay(50);
        }

        clear_screen();

        switch(colour)
        {
            case RED:
                SFont_Write(screen,ColourFont,5,5,"You are the red car");
                break;
            case GREEN:
                SFont_Write(screen,ColourFont,5,5,"You are the green car");
                break;
            case BLUE:
                SFont_Write(screen,ColourFont,5,5,"You are the blue car");
                break;
        }

        latest_event.event_time=0;
        current_event.event_time=0;

        //draw the logo
        DrawImage(logo, 0,0, logo->w, logo->h, screen, 10, 40);



        //figure out the time to end the game (2 minutes time)
        turn_start_time=SDL_GetTicks();
        turn_end_time=turn_start_time+120000;

        //the main playing loop
        while(SDL_GetTicks()<turn_end_time&&!done)
        {
            if(!easy_mode)
            {
                //increae delay time
                delay = (SDL_GetTicks()-turn_start_time)/60;
            }

            //display the current delay
            blank.x=0;
            blank.y=500;
            blank.w=800;
            blank.h=80;
            SDL_FillRect(screen,&blank,0);
            sprintf(delay_string,"Delay %.2f",((double)delay)/1000.0);
            SFont_Write (screen, Font, 10,525,delay_string);

            //display the amount of time left in this turn
            sprintf(time_left,"%d Seconds Remaining",(turn_end_time-SDL_GetTicks())/1000);
            SFont_Write (screen,Font,300,525,time_left);

            //key handler
            while (SDL_PollEvent(&keyevent))   
            {
                switch(keyevent.type)
                {
                    case SDL_QUIT:
                        done = 1;
                        break;
                    case SDL_KEYUP:
                        event_occured=1;
                        switch(keyevent.key.keysym.sym)
                        {
                            case SDLK_LEFT:
                                direction &= ~LEFT;
                                break;
                            case SDLK_RIGHT:
                                direction &= ~RIGHT;
                                break;
                            case SDLK_UP:
                                direction &= ~FORWARD;
                                break;
                            case SDLK_DOWN:
                                direction &= ~BACK;;
                                break;
                            default:
                            break;
                        }
                        break;
                    case SDL_KEYDOWN:
                        event_occured=1;
                        switch(keyevent.key.keysym.sym)
                        {
                            case SDLK_LEFT:
                                direction = direction | LEFT;
                                break;
                            case SDLK_RIGHT:
                                direction = direction | RIGHT;
                                break;
                            case SDLK_UP:
                                direction = direction | FORWARD;
                                break;
                            case SDLK_DOWN:
                                direction = direction | BACK;
                                break;
                            case SDLK_ESCAPE:
                                //end the current turn
                                turn_end_time=SDL_GetTicks();
                                break;
                            case SDLK_q:
                                q_pressed=1;
                                break;
                            case SDLK_LSHIFT:
                                shift_pressed=1;
                                break;
                            default:
                                break;
                        }
                }
            }
            //if the user pressed shift+q then exit
            if(q_pressed&&shift_pressed)
            {
                done=1;
            }
            q_pressed=0;
            shift_pressed=0;

            //only do this if a key was pressed or released
            if(event_occured)
            {
                //check for contradicitions in direction
                if(((direction&FORWARD)==FORWARD&&(direction&BACK)==BACK)||
                ((direction&LEFT)==LEFT&&(direction&RIGHT)==RIGHT))
                {
                    direction=0;
                }
    
                //add the value of the key to the event queue
                new_event.event_action=direction;
                new_event.event_time=SDL_GetTicks()+delay;
                add_to_queue(&new_event);
            }
            event_occured=0;

            //display the value we're currently outputting

            //figure out the binary to display
            if(current_event.event_time!=0&&current_event.event_time<SDL_GetTicks())
            {
                dir2=current_event.event_action;
                move(current_event.event_action);
                for(int i=0;i<4;i++)
                {   
                    if((dir2 & 0x8) !=0)
                    {
                        direction_binary[i]='1';
                    }
                    else
                    {
                        direction_binary[i]='0';
                    }
                    dir2=dir2<<1;
                }
                //remember the terminating 0
                direction_binary[4]=0;

                sprintf(direction_string,"Current command: %d In Binary: %s",current_event.event_action,direction_binary);

            }
            else
            {
                sprintf(direction_string,"Current command: 0 In Binary: 0000");
            }

            SFont_Write (screen,Font,10,550,direction_string);


            //if we aren't processing an event see if there's another one in the queue for us
            if(current_event.event_time<SDL_GetTicks())
            {
                latest_event=get_from_queue();
                if(latest_event.event_time!=0)
                {
                    //if there is make it the current event
                    current_event=latest_event;
                }
            } 


            //redraw the screen
            SDL_Flip(screen); //Refresh the screen

            //put in some delay to stop the cpu maxing out, by keeping it small we keep the car responsive
            SDL_Delay(10);

        }

        if(done==0)
        {
            //end of turn, go back to start and display 
            clear_screen();
            reset_queue();
            SFont_Write(screen, Font, 50,185,"Time's Up!, Let someone else have a go.");
            SDL_Flip(screen);
            SDL_Delay(2000);
        }
    }
}

void usage()
{
    fprintf(stderr,"client_interface -u url -e -c colour\n");
    fprintf(stderr,"-e easy mode, disables delay\n");
    fprintf(stderr,"-c colour, either r,g or b to select the colour of the car\n");
}
 
int main(int argc,char **argv) 
{
    //process command line args
    int c,res;
    opterr = 0;

    while ((c = getopt (argc, argv, "ec:")) != -1)
    {
        switch (c)
        {
            case 'c':
                switch(optarg[0])
                {
                    case 'r':
                    case 'R':
                        colour=RED;
                        break;
                    case 'b':
                    case 'B':
                        colour=BLUE;
                        break;
                    case 'g':
                    case 'G':
                        colour=GREEN;
                        break;
                    default:
                        fprintf(stderr,"error: colour must be r,g or b\n\n");
                        usage();
                        exit(1);
                        break;
                }
                break;
            case 'e':
                easy_mode=1;
                break;
            case '?':
                fprintf (stderr,"Unknown option character `\\x%x'.\n",optopt);
                exit(1);
            default:
                usage();
                exit(1);
                break;
        }
    }


    if (InitVideo() == false) 
    {
        return 1;
    }


    //network_init();

    //give the window a title
    SDL_WM_SetCaption("Remote Control Car",NULL);

    //setup the font
    Font = SFont_InitFont(IMG_Load("font.png"));
    if(!Font) {
        fprintf(stderr, "An error occured while loading the font.");
        exit(1);
    }

    //reload our image file
    logo = LoadImage("default.png",res);
    if (res)
    {
        //setup the parallel port
        parport_init();
        atexit(SDL_Quit);           /* Clean up on exit */
        //do everything!
        mainloop();
    }
    //stop the car moving
    stop();
    //cleanup
    SDL_FreeSurface(logo);
    return 0;
}
