typedef struct event {
    uint32_t event_time;
    uint8_t event_action;
} event_item;

void init_queue();
void add_to_queue(event_item *new_item);
event_item get_from_queue();
void reset_queue();
