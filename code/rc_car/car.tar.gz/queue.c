/*
event queue handling for remote control car system.
(C) Copyright Colin Sauze 2007
http://users.aber.ac.uk/cjs06/rc_car

This code allows an event queue of up to 200 events to be created. 
An event is defined as when a user presses or releases a key. 
For example if the user presses the up arrow this sends a 1 into the queue.
When they release it, it will send a 0 into the queue. 

Events have an expiry time associated with them. this is the earliest time
at which the event is to be executed. This is used to give a delay between the 
user pressing the key and the event being executed.

This program is released under the GPL, here's the legal bit:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include "queue.h"

#define QUEUE_SIZE 200

event_item event_queue[QUEUE_SIZE];
int head,tail,size;


void init_queue()
{
    memset(event_queue,0,sizeof(event_item)*QUEUE_SIZE);
    head=0;
    tail=0;
    size=0;
    event_queue[0].event_time=0;
}

/*
adds a new item to the tail of the queue
*/
void add_to_queue(event_item *new_item)
{
    //check the queue is not full, ignore this request if the queue is full
    //if the queue fills its not a problem, its just some key presses get lost
    if(head!=tail||size==0)
    {
        event_queue[tail].event_action=new_item->event_action;
        event_queue[tail].event_time=new_item->event_time;
        tail++;
        tail=tail%QUEUE_SIZE;
        size++;
    }
}

/*
returns the item from the head of the queue and removes it from the queue
*/
event_item get_from_queue()
{
    int old_head;
    if(size>0)
    {
        old_head=head;
        head++;
        size--;
        head = head % QUEUE_SIZE;
        return event_queue[old_head];
    }
    else
    {
        event_item null_item;
        null_item.event_time=0;
        null_item.event_action=0;
        return null_item;
    }
}

/*
resets the queue and removes all items in it
*/
void reset_queue()
{
    memset(event_queue,0,sizeof(event_item)*QUEUE_SIZE);
    head=0;
    tail=0;
    size=0;
}
