#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <stdint.h>

#include "SDL.h" 
#include "SDL_net.h" 
#include "get_image.h"

TCPsocket sock;
uint8_t connection_lost=0;

void network_init()
{
    // initialize SDL_net 
    if(SDLNet_Init()==-1)
    {
        printf("SDLNet_Init: %s\n",SDLNet_GetError());
        exit(0);
    }
}

void network_deinit()
{
    SDLNet_Quit();
}

void get_image(char *url)
{
    char message[100000];
    char header[2000];
    char server[100];
    char path[100];
    char port[6];
    //char *get_request="GET /~colin/test.jpg HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n";
    char get_request[250];
    int len, result; 
    FILE *fptr;
    int i=0;
    int colon_offset=0,slash_offset=0;
    char *content_length_str;
    int content_length,total_size=0;

    IPaddress ip;

    //look for a : in the path
    for(i=7;i<strlen(url);i++)
    {
        if(url[i]==':')
        {
            colon_offset=i;
            break;
        }
    }

    for(i=7;i<strlen(url);i++)
    {
        if(url[i]=='/')
        {
            slash_offset=i;
            break;
        }
    }

    if(colon_offset>0)
    {
        memcpy(server,url+7,colon_offset-7);
        server[colon_offset-6]=0;


        memcpy(port,url+colon_offset+1,slash_offset-colon_offset-1);
        port[slash_offset-colon_offset-1]=0;
    }
    else
    {
        memcpy(server,url+7,slash_offset-7);
        server[slash_offset-7]=0;
        strcpy(port,"80");
    }

    memcpy(path,url+slash_offset,strlen(url)-slash_offset);

    path[strlen(url)-slash_offset]=0;


    //"GET /~colin/test.jpg HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n";
    sprintf(get_request,"GET %s HTTP/1.1\r\nHost: %s\r\n\r\n",path,server);
    // Resolve the argument into an IPaddress type
    if(!SDLNet_ResolveHost(&ip,server,atoi(port)))
    {
        // open socket
        sock=SDLNet_TCP_Open(&ip); 
        if(!sock)
        {
            printf("SDLNet_TCP_Open: %s\n",SDLNet_GetError());
            exit(0);
        }
    }
    else
    {
        printf("SDLNet_ResolveHost: %s\n",SDLNet_GetError());
        exit(0);
    }

    result = SDLNet_TCP_Send(sock,get_request,strlen(get_request));
    if(result<1)
    {
        printf("SDLNet_TCP_Send: %s\n",SDLNet_GetError());
        printf("connection lost, reconnecting\n");
        result = SDLNet_TCP_Send(sock,get_request,strlen(get_request));
    }

    // read the buffer from server 
    len=SDLNet_TCP_Recv(sock, message,100000);

    //write file to disk but ignore the header
    //end of header is when we get 0xd 0xa 0xd 0xa

    if(len)
    {
        char data[4];
        while(i<len)
        {
            if(message[i]==0xd)
            {
                data[0]=message[i];
                data[1]=message[i+1];
                data[2]=message[i+2];
                data[3]=message[i+3];
                if(data[0]==0xd&&data[1]==0xa&&data[2]==0xd&&data[3]==0xa)
                {
                    i=i+4;
                    break;
                }
            }
            i++;
        }
        memcpy(header,message,i+4);
        header[i+4]=0;

        //get content-length from the header
        content_length_str=strstr(header,"Content-Length:");

        sscanf(content_length_str,"Content-Length: %d\n",&content_length);

        //don't download empty images
        if(i<len)
        {
            //should have found the end of the header, start dumping data
            fptr=fopen("/tmp/test.jpg","w");
            while(total_size<content_length)
            {
                while(i<len)
                {
                    fputc(message[i],fptr);
                    i++;
                    total_size++;
                }
                if(content_length-total_size>0)
                {
                    len=SDLNet_TCP_Recv(sock, message,content_length-total_size);
                    i=0;
                }
            }

            
            fclose(fptr);
        }
    }
    else
    {
        //server has closed the connection, reopen it
        printf("SDLNet_TCP_Recv: %s\n",SDLNet_GetError());
    }
    SDLNet_TCP_Close(sock);
}
