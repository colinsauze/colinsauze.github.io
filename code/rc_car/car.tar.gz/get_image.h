void network_init();
void network_deinit();
void get_image(char *url);
void reconnect();
